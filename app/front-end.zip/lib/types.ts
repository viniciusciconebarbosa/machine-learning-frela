export interface Aluno {
  Altura: number
  Email: string
  Frequencia_Semanal: number
  Genero: number
  ID: number
  IMC: number
  Idade: number
  Nome: string
  Objetivo: number
  Peso: number
  Plano: number
  Presencas_Ultimo_Mes: number
  Prob_Churn: number
  Tempo_de_Assinatura: number
}
